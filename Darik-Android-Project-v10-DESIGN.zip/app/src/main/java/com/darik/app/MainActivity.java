package com.darik.app;
import android.content.*;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {
    private EditText search;
    private TextView history;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        MaterialButton start = findViewById(R.id.btnStart);
        TextView unknown = findViewById(R.id.btnUnknown);
        history = findViewById(R.id.historyText);
        search = findViewById(R.id.searchInput);
        updateCount();
        start.setOnClickListener(v -> open(search.getText().toString().trim()));
        search.setOnEditorActionListener((v, actionId, event) -> { open(search.getText().toString().trim()); return true; });
        unknown.setOnClickListener(v -> open(""));
        findViewById(R.id.btnHistory).setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
        findViewById(R.id.btnDevices).setOnClickListener(v -> startActivity(new Intent(this, DevicesActivity.class)));
        findViewById(R.id.navHome).setOnClickListener(v -> { });
        findViewById(R.id.navDiagnosis).setOnClickListener(v -> open(""));
        findViewById(R.id.navDevices).setOnClickListener(v -> startActivity(new Intent(this, DevicesActivity.class)));
        findViewById(R.id.navHistory).setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
        findViewById(R.id.navSafety).setOnClickListener(v -> new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("السلامة أولًا")
            .setMessage("افصل مصدر الكهرباء عند وجود خطر. لا تلمس الأسلاك المكشوفة، ولا تحاول إصلاح الغاز بنفسك. عند الشك، استعِن بفني مختص.")
            .setPositiveButton("حسنًا", (dialog, which) -> dialog.dismiss()).show());
        bindCategory(R.id.catCooling, "التكييف التبريد");
        bindCategory(R.id.catLaundry, "الغسالة");
        bindCategory(R.id.catKitchen, "المطبخ الفرن");
        bindCategory(R.id.catPlumbing, "السباكة تسريب مياه");
        bindCategory(R.id.catElectric, "الكهرباء الجهاز لا يعمل");
        bindCategory(R.id.catElectronics, "التلفاز الإلكترونيات");
        bindCategory(R.id.issueNoPower, "الجهاز لا يعمل");
        bindCategory(R.id.issueLeak, "تسريب مياه");
        bindCategory(R.id.issueNoise, "صوت غير طبيعي اهتزاز");
        bindCategory(R.id.issueCooling, "ضعف التبريد أو التسخين");
    }

    private void bindCategory(int id, String query) {
        View view = findViewById(id);
        if (view != null) view.setOnClickListener(v -> open(query));
    }
    private void open(String mode) {
        Intent intent = new Intent(this, DiagnosisActivity.class);
        intent.putExtra("mode", mode == null ? "" : mode);
        startActivity(intent);
    }
    private void updateCount() {
        history.setText(new RepairStore(this).count() + " عملية محفوظة");
    }
}
