# دارك — الإصدار 14 (مراجعة واجهة وأيقونات)

تتضمن هذه النسخة إعادة تنظيم الصفحة الرئيسية لتقترب من المرجع البصري الأزرق/البرتقالي: رأس RTL واضح، بانر رئيسي مع رسم منزلي، حقل بحث منفصل، بطاقات الأجهزة ذات الرسوم المتجهية، اختصارات، أعطال شائعة، وشريط تنقل سفلي بأيقونات متناسقة. تم الإبقاء على معرّفات عناصر التنقل والتشخيص المستخدمة في MainActivity.

## البناء على GitHub Actions
1. ضع `Darik-Android-Project-v15-PRO-UI.zip` في جذر المستودع.
2. استبدل أيضًا الملف `.github/workflows/build-apk.yml` بالنسخة الموجودة في هذا المشروع. هذه نقطة مهمة: سير البناء القديم قد يتجاهل ZIP إذا كان مشروع Gradle القديم موجودًا بالفعل في الجذر.
3. افتح Actions وشغّل `Build Darik APK` وانتظر نجاح خطوة التحقق والبناء.
4. نزّل Artifact باسم `Darik-v15-debug-apk`.

الإصدار 14 لا يغيّر معرّف التطبيق `com.darik.app` للمحافظة على التوافق مع التطبيق المثبت. لم يتم ادعاء نجاح بناء APK قبل تشغيله عبر GitHub Actions.


## Design revision 15
- Refined blue/orange brand palette, higher-contrast surfaces, more spacious appliance cards, and stronger home banner.
- Preserves existing self-repair diagnosis, history, device navigation, and safety guidance.
- Package ID remains `com.darik.app` to support updating an installed build rather than installing a separate app.

## v16 review notes

- Kept the existing native Android project, app ID (`com.darik.app`), and self-repair flows.
- Updated the version to 16.0.0 and enabled `adjustResize` for the keyboard/search interaction.
- Updated the GitHub Actions workflow to select the exact `Darik-Android-Project-v16-REVIEWED.zip`, validate XML/JSON and home-screen IDs, build a debug APK, and publish the APK artifact.
- Static resource and reference validation was performed when packaging. A full Android Gradle build and on-device visual verification still need to run in GitHub Actions/on the phone.
