package com.darik.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.DateFormat;
import java.util.*;

public class RepairStore {
    private final SharedPreferences p;
    public RepairStore(Context c){ p=c.getSharedPreferences("darik_store",Context.MODE_PRIVATE); }
    public void saveRepair(String device,String result){
        try{ JSONArray a=new JSONArray(p.getString("repairs","[]")); JSONObject o=new JSONObject();
            o.put("device",device); o.put("result",result); o.put("time",System.currentTimeMillis()); a.put(o);
            p.edit().putString("repairs",a.toString()).apply();
        }catch(Exception ignored){}
    }
    public int count(){ try{return new JSONArray(p.getString("repairs","[]")).length();}catch(Exception e){return 0;} }
    public List<String> summaries(){
        List<String> out=new ArrayList<>();
        try{ JSONArray a=new JSONArray(p.getString("repairs","[]"));
            for(int i=a.length()-1;i>=0;i--){ JSONObject o=a.getJSONObject(i); Date d=new Date(o.optLong("time"));
                out.add(o.optString("device","مشكلة منزلية")+"\n"+o.optString("result","")+"\n"+DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(d)); }
        }catch(Exception ignored){}
        return out;
    }
    public void saveDevice(String name,String model){
        if(name==null||name.trim().isEmpty()) return;
        try{ JSONArray a=new JSONArray(p.getString("devices","[]")); JSONObject o=new JSONObject(); o.put("name",name);o.put("model",model);o.put("time",System.currentTimeMillis());a.put(o);p.edit().putString("devices",a.toString()).apply(); }catch(Exception ignored){}
    }

    public void deleteDevice(String device) {
        try {
            JSONArray old = new JSONArray(p.getString("devices", "[]"));
            JSONArray kept = new JSONArray();
            boolean removed = false;
            for (int i = 0; i < old.length(); i++) {
                JSONObject o = old.getJSONObject(i);
                String label = o.optString("name") + (o.optString("model").isEmpty() ? "" : " — " + o.optString("model"));
                if (!removed && label.equals(device)) { removed = true; continue; }
                kept.put(o);
            }
            p.edit().putString("devices", kept.toString()).apply();
        } catch (Exception ignored) {}
    }

    public List<String> devices(){
        List<String> out=new ArrayList<>(); try{JSONArray a=new JSONArray(p.getString("devices","[]")); for(int i=a.length()-1;i>=0;i--){JSONObject o=a.getJSONObject(i);out.add(o.optString("name")+(o.optString("model").isEmpty()?"":" — "+o.optString("model")));}}catch(Exception ignored){} return out;
    }
}
