package com.darik.app;

import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class DevicesActivity extends AppCompatActivity {
    private LinearLayout list;
    private EditText name, model;
    private RepairStore store;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        store = new RepairStore(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 18, 20, 18);
        root.setBackgroundColor(Color.rgb(243, 246, 252));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView back = text("‹", 32, true);
        back.setGravity(android.view.Gravity.CENTER);
        top.addView(back, new LinearLayout.LayoutParams(48, 52));
        back.setOnClickListener(v -> finish());
        TextView title = text("أجهزتي", 25, true);
        top.addView(title, new LinearLayout.LayoutParams(0, 52, 1));
        root.addView(top);
        root.addView(text("أضف أجهزتك لتسهيل الرجوع إليها عند تشخيص الأعطال.", 14, false));

        name = new EditText(this); name.setSingleLine(true); name.setHint("اسم الجهاز — مثال: ثلاجة المطبخ");
        root.addView(name, new LinearLayout.LayoutParams(-1, 58));
        model = new EditText(this); model.setSingleLine(true); model.setHint("الماركة / الموديل (اختياري)");
        root.addView(model, new LinearLayout.LayoutParams(-1, 58));
        Button add = new Button(this); add.setText("حفظ الجهاز"); root.addView(add, new LinearLayout.LayoutParams(-1, 54));
        add.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            if (n.isEmpty()) { name.setError("اكتب اسم الجهاز أولًا"); name.requestFocus(); return; }
            store.saveDevice(n, model.getText().toString().trim());
            name.setText(""); model.setText("");
            Toast.makeText(this, "تم حفظ الجهاز", Toast.LENGTH_SHORT).show(); refresh();
        });

        TextView savedTitle = text("الأجهزة المحفوظة", 19, true);
        savedTitle.setPadding(0, 20, 0, 8); root.addView(savedTitle);
        ScrollView scroll = new ScrollView(this); list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root); refresh();
    }

    private void refresh() {
        list.removeAllViews();
        List<String> devices = store.devices();
        if (devices.isEmpty()) {
            TextView empty = text("لا توجد أجهزة محفوظة حتى الآن. أضف جهازك من الأعلى.", 15, false);
            empty.setPadding(14, 18, 14, 18); list.addView(empty); return;
        }
        for (String device : devices) {
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(android.view.Gravity.CENTER_VERTICAL);
            card.setPadding(14, 10, 14, 10); card.setBackgroundResource(R.drawable.bg_card);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.setMargins(0, 0, 0, 10); list.addView(card, cp);
            TextView label = text("▣  " + device, 16, true); card.addView(label, new LinearLayout.LayoutParams(0, -2, 1));
            Button delete = new Button(this); delete.setText("حذف"); card.addView(delete);
            delete.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("حذف الجهاز")
                .setMessage("هل تريد حذف «" + device + "» من أجهزتك المحفوظة؟")
                .setNegativeButton("إلغاء", null).setPositiveButton("حذف", (d, w) -> {
                    store.deleteDevice(device); refresh();
                }).show());
        }
    }

    private TextView text(String s, int size, boolean bold) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(Color.rgb(20, 35, 60));
        if (bold) v.setTypeface(null, android.graphics.Typeface.BOLD); return v;
    }
}
