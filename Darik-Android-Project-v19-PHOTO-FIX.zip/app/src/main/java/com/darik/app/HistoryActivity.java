package com.darik.app;

import android.os.Bundle;
import android.graphics.Color;
import android.net.Uri;
import android.view.Gravity;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {
    private LinearLayout list;
    private RepairStore store;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); store = new RepairStore(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 18, 20, 18); root.setBackgroundColor(Color.rgb(243,246,252));
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = text("‹", 32, true); back.setGravity(Gravity.CENTER); top.addView(back, new LinearLayout.LayoutParams(48, 52));
        back.setOnClickListener(v -> finish()); TextView title = text("إصلاحاتي", 25, true); top.addView(title, new LinearLayout.LayoutParams(0,52,1)); root.addView(top);
        root.addView(text("هنا تظهر عمليات التشخيص التي حفظتها من دارك، من الأحدث إلى الأقدم.", 14, false));
        ScrollView scroll = new ScrollView(this); list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1)); setContentView(root); refresh();
    }

    @Override protected void onResume() { super.onResume(); if (list != null && store != null) refresh(); }

    private void refresh() {
        list.removeAllViews(); List<String> items = store.summaries();
        if (items.isEmpty()) {
            TextView empty = text("لا توجد إصلاحات محفوظة بعد. ابدأ تشخيص مشكلة من الصفحة الرئيسية، ثم احفظ النتيجة لتظهر هنا.", 16, false);
            empty.setPadding(16, 22, 16, 22); empty.setBackgroundResource(R.drawable.bg_card); list.addView(empty); return;
        }
        List<List<String>> photos = store.repairImages();
        for (int idx=0; idx<items.size(); idx++) {
            String item=items.get(idx);
            LinearLayout cardBox = new LinearLayout(this); cardBox.setOrientation(LinearLayout.VERTICAL); cardBox.setPadding(14, 12, 14, 12); cardBox.setBackgroundResource(R.drawable.bg_card);
            TextView card = text(item, 15, false); card.setPadding(4, 4, 4, 8); cardBox.addView(card);
            if(idx<photos.size() && !photos.get(idx).isEmpty()){
                HorizontalScrollView hsv=new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false);
                LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
                for(String uriText:photos.get(idx)){ try{ ImageView image=new ImageView(this); LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(104,104); ip.setMargins(4,4,8,4); image.setLayoutParams(ip); image.setScaleType(ImageView.ScaleType.CENTER_CROP); image.setImageURI(Uri.parse(uriText)); row.addView(image); }catch(Exception ignored){} }
                hsv.addView(row); cardBox.addView(hsv);
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 12, 0, 0); list.addView(cardBox, lp);
        }
    }
    private TextView text(String s, int size, boolean bold) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(Color.rgb(20,35,60));
        if (bold) v.setTypeface(null, android.graphics.Typeface.BOLD); return v;
    }
}
