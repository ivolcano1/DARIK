package com.darik.app;
import android.content.Context;import org.json.*;import java.io.*;import java.nio.charset.StandardCharsets;import java.util.*;
public class KnowledgeBase {
 public static class Device {String name,category;boolean danger;int baseConfidence=60;List<String> keywords=new ArrayList<>(),questions=new ArrayList<>(),diagnoses=new ArrayList<>(),tools=new ArrayList<>(),steps=new ArrayList<>(),symptoms=new ArrayList<>();}
 private final List<Device> devices=new ArrayList<>();
 public KnowledgeBase(Context c){try(InputStream in=c.getAssets().open("knowledge.json")){byte[] b=new byte[in.available()];in.read(b);JSONArray a=new JSONObject(new String(b,StandardCharsets.UTF_8)).getJSONArray("devices");for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Device d=new Device();d.name=o.getString("name");d.category=o.getString("category");d.danger=o.optBoolean("danger",false);d.baseConfidence=Math.max(40,Math.min(90,o.optInt("baseConfidence",60)));fill(o.optJSONArray("keywords"),d.keywords);fill(o.optJSONArray("questions"),d.questions);fill(o.optJSONArray("diagnoses"),d.diagnoses);fill(o.optJSONArray("tools"),d.tools);fill(o.optJSONArray("steps"),d.steps);fill(o.optJSONArray("symptoms"),d.symptoms);devices.add(d);}}catch(Exception e){throw new RuntimeException(e);}}
 void fill(JSONArray a,List<String> out){if(a!=null)for(int i=0;i<a.length();i++)out.add(a.optString(i));}
 public List<Device> all(){return devices;}
 public Device find(String text){String n=(text==null?"":text).trim().toLowerCase(Locale.ROOT);if(n.isEmpty())return null;Device best=null;int score=0;for(Device d:devices){int s=0;if(n.contains(d.name.toLowerCase(Locale.ROOT)))s+=5;for(String k:d.keywords)if(n.contains(k.toLowerCase(Locale.ROOT)))s+=3;for(String x:d.symptoms)if(n.contains(x.toLowerCase(Locale.ROOT)))s++;if(s>score){score=s;best=d;}}return score>0?best:null;}
}
