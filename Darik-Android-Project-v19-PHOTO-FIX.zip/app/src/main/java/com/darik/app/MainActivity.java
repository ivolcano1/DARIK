package com.darik.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {
    private EditText search;
    private TextView history;
    private ScrollView homeScroll;
    private View searchWrap;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);

        MaterialButton start = findViewById(R.id.btnStart);
        TextView unknown = findViewById(R.id.btnUnknown);
        history = findViewById(R.id.historyText);
        search = findViewById(R.id.searchInput);
        homeScroll = findViewById(R.id.homeScroll);
        searchWrap = findViewById(R.id.searchWrap);

        updateCount();
        start.setOnClickListener(v -> open(search.getText().toString().trim()));
        search.setOnEditorActionListener((v, actionId, event) -> {
            open(search.getText().toString().trim());
            return true;
        });
        unknown.setOnClickListener(v -> open(""));

        findViewById(R.id.btnTopSearch).setOnClickListener(v -> focusSearch());
        findViewById(R.id.btnMenu).setOnClickListener(v -> showMainMenu());
        findViewById(R.id.btnHistory).setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
        findViewById(R.id.btnDevices).setOnClickListener(v -> startActivity(new Intent(this, DevicesActivity.class)));
        // Main navigation is now in the header menu to free screen space for the repair dashboard.

        bindCategory(R.id.catCooling, "التكييف التبريد");
        bindCategory(R.id.catLaundry, "الغسالة تصريف ماء");
        bindCategory(R.id.catKitchen, "المطبخ الفرن");
        bindCategory(R.id.catPlumbing, "السباكة تسريب مياه");
        bindCategory(R.id.catElectric, "الكهرباء الجهاز لا يعمل");
        bindCategory(R.id.catElectronics, "التلفاز الإلكترونيات");
        bindCategory(R.id.issueNoPower, "الجهاز لا يعمل");
        bindCategory(R.id.issueLeak, "تسريب مياه");
        bindCategory(R.id.issueNoise, "صوت غير طبيعي اهتزاز");
        bindCategory(R.id.issueCooling, "ضعف التبريد أو التسخين");
    }


    private void showMainMenu() {
        final String[] items = {"الرئيسية", "ابدأ التشخيص", "أجهزتي والأجهزة المحفوظة", "إصلاحاتي", "السلامة أولًا"};
        new AlertDialog.Builder(this)
            .setTitle("قائمة دارك")
            .setItems(items, (dialog, which) -> {
                switch (which) {
                    case 0:
                        homeScroll.smoothScrollTo(0, 0);
                        search.clearFocus();
                        break;
                    case 1: open(""); break;
                    case 2: startActivity(new Intent(this, DevicesActivity.class)); break;
                    case 3: startActivity(new Intent(this, HistoryActivity.class)); break;
                    case 4:
                        new AlertDialog.Builder(this)
                            .setTitle("السلامة أولًا")
                            .setMessage("افصل مصدر الكهرباء عند وجود خطر. لا تلمس الأسلاك المكشوفة، ولا تفتح الأجهزة أو توصيلات الغاز بنفسك. عند الشك، أوقف الاستخدام واستعن بفني مختص.")
                            .setPositiveButton("حسنًا", (d, w) -> d.dismiss()).show();
                        break;
                }
            }).show();
    }

    private void focusSearch() {
        homeScroll.smoothScrollTo(0, Math.max(0, searchWrap.getTop()));
        search.requestFocus();
        search.post(() -> {
            InputMethodManager keyboard = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (keyboard != null) keyboard.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT);
        });
    }

    private void bindCategory(int id, String query) {
        View view = findViewById(id);
        if (view != null) view.setOnClickListener(v -> open(query));
    }

    private void open(String mode) {
        Intent intent = new Intent(this, DiagnosisActivity.class);
        intent.putExtra("mode", mode == null ? "" : mode);
        startActivity(intent);
    }

    private void updateCount() {
        if (history != null) history.setText(new RepairStore(this).count() + " عملية محفوظة");
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCount();
    }
}
