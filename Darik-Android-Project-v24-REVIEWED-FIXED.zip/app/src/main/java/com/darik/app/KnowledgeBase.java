package com.darik.app;
import android.content.Context;import org.json.*;import java.io.*;import java.nio.charset.StandardCharsets;import java.util.*;
public class KnowledgeBase {
 public static class Device {String name,category;boolean danger;int baseConfidence=60;List<String> keywords=new ArrayList<>(),questions=new ArrayList<>(),diagnoses=new ArrayList<>(),tools=new ArrayList<>(),steps=new ArrayList<>(),symptoms=new ArrayList<>();}
 private final List<Device> devices=new ArrayList<>();
 public KnowledgeBase(Context c){try(InputStream in=c.getAssets().open("knowledge.json")){byte[] b=new byte[in.available()];in.read(b);JSONArray a=new JSONObject(new String(b,StandardCharsets.UTF_8)).getJSONArray("devices");for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Device d=new Device();d.name=o.getString("name");d.category=o.getString("category");d.danger=o.optBoolean("danger",false);d.baseConfidence=Math.max(40,Math.min(90,o.optInt("baseConfidence",60)));fill(o.optJSONArray("keywords"),d.keywords);fill(o.optJSONArray("questions"),d.questions);fill(o.optJSONArray("diagnoses"),d.diagnoses);fill(o.optJSONArray("tools"),d.tools);fill(o.optJSONArray("steps"),d.steps);fill(o.optJSONArray("symptoms"),d.symptoms);devices.add(d);}}catch(Exception e){throw new RuntimeException(e);}}
 void fill(JSONArray a,List<String> out){if(a!=null)for(int i=0;i<a.length();i++)out.add(a.optString(i));}
 public List<Device> all(){return devices;}
 private String norm(String value){
  if(value==null)return "";
  String s=value.toLowerCase(Locale.ROOT).trim();
  s=s.replace('أ','ا').replace('إ','ا').replace('آ','ا').replace('ى','ي').replace('ة','ه').replace('ؤ','و').replace('ئ','ي');
  s=s.replaceAll("[ًٌٍَُِّْـ]", " ").replaceAll("[^\\p{L}\\p{N} ]", " ").replaceAll("\\s+", " ").trim();
  return s;
 }
 public Device find(String text){
  String n=norm(text); if(n.isEmpty())return null;
  String[] query=n.split(" "); Device best=null; int bestScore=0;
  for(Device d:devices){
   int score=0; String name=norm(d.name), category=norm(d.category);
   if(n.contains(name)||name.contains(n))score+=8;
   if(!category.isEmpty()&&n.contains(category))score+=2;
   for(String k:d.keywords){String key=norm(k);if(key.isEmpty())continue;if(n.contains(key))score+=5;else for(String token:query)if(token.length()>2&&(key.contains(token)||token.contains(key))){score+=2;break;}}
   for(String symptom:d.symptoms){String key=norm(symptom);if(key.isEmpty())continue;if(n.contains(key))score+=4;else for(String token:query)if(token.length()>2&&key.contains(token)){score++;break;}}
   for(String token:query){if(token.length()<3)continue;if(name.contains(token))score+=2;}
   if(score>bestScore){bestScore=score;best=d;}
  }
  return bestScore>=3?best:null;
 }

}
