package com.darik.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import android.app.Dialog;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.graphics.Typeface;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {
    private EditText search;
    private TextView history;
    private ScrollView homeScroll;
    private View searchWrap;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);

        MaterialButton start = findViewById(R.id.btnStart);
        TextView unknown = findViewById(R.id.btnUnknown);
        history = findViewById(R.id.historyText);
        search = findViewById(R.id.searchInput);
        homeScroll = findViewById(R.id.homeScroll);
        searchWrap = findViewById(R.id.searchWrap);

        updateCount();
        start.setOnClickListener(v -> submitSearch());
        search.setOnEditorActionListener((v, actionId, event) -> {
            submitSearch();
            return true;
        });
        findViewById(R.id.btnSearchSubmit).setOnClickListener(v -> submitSearch());
        unknown.setOnClickListener(v -> open(""));

        findViewById(R.id.btnTopSearch).setOnClickListener(v -> focusSearch());
        findViewById(R.id.btnMenu).setOnClickListener(v -> showMainMenu());
        findViewById(R.id.btnHistory).setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
        findViewById(R.id.btnDevices).setOnClickListener(v -> startActivity(new Intent(this, DevicesActivity.class)));
        // Main navigation is now in the header menu to free screen space for the repair dashboard.

        bindCategory(R.id.catCooling, "التكييف التبريد");
        bindCategory(R.id.catLaundry, "الغسالة تصريف ماء");
        bindCategory(R.id.catKitchen, "المطبخ الفرن");
        bindCategory(R.id.catPlumbing, "السباكة تسريب مياه");
        bindCategory(R.id.catElectric, "الكهرباء الجهاز لا يعمل");
        bindCategory(R.id.catElectronics, "التلفاز الإلكترونيات");
        bindCategory(R.id.issueNoPower, "الجهاز لا يعمل");
        bindCategory(R.id.issueLeak, "تسريب مياه");
        bindCategory(R.id.issueNoise, "صوت غير طبيعي اهتزاز");
        bindCategory(R.id.issueCooling, "ضعف التبريد");
        bindCategory(R.id.issueDrain, "انسداد التصريف لا يصرف الماء");
        bindCategory(R.id.issueHeat, "لا يسخن الماء أو الطعام");
        bindCategory(R.id.issuePowerTrip, "القاطع يفصل الكهرباء");
        bindCategory(R.id.issueVibration, "الغسالة تهتز بشدة");
    }


    private void showMainMenu() {
        final Dialog dialog = new Dialog(this);
        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(Color.TRANSPARENT);
        overlay.setOnClickListener(v -> dialog.dismiss());

        LinearLayout drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        drawer.setPadding(dp(18), dp(24), dp(18), dp(16));
        drawer.setBackgroundColor(Color.WHITE);
        drawer.setElevation(dp(12));
        FrameLayout.LayoutParams drawerParams = new FrameLayout.LayoutParams(dp(310), -1, Gravity.RIGHT | Gravity.TOP);
        drawerParams.width = Math.min(dp(310), getResources().getDisplayMetrics().widthPixels - dp(24));
        overlay.addView(drawer, drawerParams);
        drawer.setOnClickListener(v -> { /* Keep taps inside the drawer from dismissing it. */ });

        TextView heading = new TextView(this);
        heading.setText("دارك\nصيانة بيتك خطوة بخطوة");
        heading.setTextSize(22);
        heading.setTypeface(null, Typeface.BOLD);
        heading.setTextColor(Color.rgb(20, 48, 87));
        heading.setPadding(dp(8), dp(8), dp(8), dp(22));
        drawer.addView(heading, new LinearLayout.LayoutParams(-1, -2));

        addMenuRow(drawer, "⌂", "الرئيسية", () -> {
            homeScroll.smoothScrollTo(0, 0);
            search.clearFocus();
        }, dialog);
        addMenuRow(drawer, "⌕", "ابدأ التشخيص", () -> open(""), dialog);
        addMenuRow(drawer, "▦", "أجهزتي", () -> startActivity(new Intent(this, DevicesActivity.class)), dialog);
        addMenuRow(drawer, "▣", "الأجهزة المحفوظة", () -> startActivity(new Intent(this, DevicesActivity.class)), dialog);
        addMenuRow(drawer, "◷", "إصلاحاتي", () -> startActivity(new Intent(this, HistoryActivity.class)), dialog);
        addMenuRow(drawer, "◇", "السلامة أولًا", () -> new AlertDialog.Builder(this)
            .setTitle("السلامة أولًا")
            .setMessage("أوقف الجهاز عند وجود شرر أو رائحة احتراق أو تسريب غاز. لا تفتح الأجهزة أو التوصيلات الخطرة بنفسك. افصل الطاقة فقط إذا كان ذلك آمنًا، واستعن بمختص عند الحاجة.")
            .setPositiveButton("حسنًا", null).show(), dialog);

        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(225, 232, 242));
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(-1, dp(1));
        dividerParams.setMargins(0, dp(14), 0, dp(14));
        drawer.addView(divider, dividerParams);
        TextView note = new TextView(this);
        note.setText("بحث محلي يعمل دون ذكاء اصطناعي");
        note.setTextSize(13);
        note.setTextColor(Color.rgb(95, 110, 130));
        note.setPadding(dp(8), dp(8), dp(8), dp(8));
        drawer.addView(note);

        dialog.setContentView(overlay);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams attrs = window.getAttributes();
            attrs.width = WindowManager.LayoutParams.MATCH_PARENT;
            attrs.height = WindowManager.LayoutParams.MATCH_PARENT;
            attrs.gravity = Gravity.TOP | Gravity.RIGHT;
            attrs.dimAmount = 0.45f;
            window.setAttributes(attrs);
        }
        dialog.show();
        if (window != null) window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
    }

    private void addMenuRow(LinearLayout drawer, String symbol, String label, Runnable action, Dialog dialog) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setPadding(dp(10), 0, dp(10), 0);
        row.setBackgroundResource(R.drawable.bg_card);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, dp(54));
        rowParams.setMargins(0, dp(4), 0, dp(4));
        drawer.addView(row, rowParams);
        TextView icon = new TextView(this);
        icon.setText(symbol);
        icon.setTextSize(23);
        icon.setTextColor(Color.rgb(30, 100, 190));
        icon.setGravity(Gravity.CENTER);
        row.addView(icon, new LinearLayout.LayoutParams(dp(38), -1));
        TextView title = new TextView(this);
        title.setText(label);
        title.setTextSize(16);
        title.setTextColor(Color.rgb(25, 42, 66));
        title.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        row.addView(title, new LinearLayout.LayoutParams(0, -1, 1));
        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(v -> { dialog.dismiss(); action.run(); });
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void focusSearch() {
        homeScroll.smoothScrollTo(0, Math.max(0, searchWrap.getTop()));
        search.requestFocus();
        search.post(() -> {
            InputMethodManager keyboard = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (keyboard != null) keyboard.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT);
        });
    }

    private void bindCategory(int id, String query) {
        View view = findViewById(id);
        if (view != null) view.setOnClickListener(v -> open(query));
    }

    private void open(String mode) {
        Intent intent = new Intent(this, DiagnosisActivity.class);
        intent.putExtra("mode", mode == null ? "" : mode);
        startActivity(intent);
    }

    private void submitSearch() {
        String query = search.getText().toString().trim();
        if (query.isEmpty()) {
            Toast.makeText(this, "اكتب اسم الجهاز أو وصف العطل أولًا", Toast.LENGTH_SHORT).show();
            focusSearch();
            return;
        }
        open(query);
    }

    private void updateCount() {
        if (history != null) history.setText(new RepairStore(this).count() + " عملية محفوظة");
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCount();
    }
}
