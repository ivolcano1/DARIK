package com.darik.app;

import android.content.*;import android.net.Uri;import android.os.Bundle;import android.graphics.Bitmap;import android.graphics.BitmapFactory;import android.view.*;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;import java.util.*;import java.io.*;

public class DiagnosisActivity extends AppCompatActivity {
    KnowledgeBase kb; KnowledgeBase.Device d; EditText device,problem; TextView photoStatus,qTitle,qBody,safety,result,tools,steps,confidence; LinearLayout questionBox,resultBox,photosPreview; HorizontalScrollView photosScroll; int qi; ArrayList<Uri> images=new ArrayList<>(); ArrayList<Boolean> answers=new ArrayList<>();
    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_diagnosis);kb=new KnowledgeBase(this);device=findViewById(R.id.deviceText);problem=findViewById(R.id.problemText);photoStatus=findViewById(R.id.photoStatus);photosPreview=findViewById(R.id.photosPreview);photosScroll=findViewById(R.id.photosScroll);questionBox=findViewById(R.id.questionBox);qTitle=findViewById(R.id.questionTitle);qBody=findViewById(R.id.questionBody);resultBox=findViewById(R.id.resultBox);safety=findViewById(R.id.safetyText);result=findViewById(R.id.resultText);tools=findViewById(R.id.toolsText);steps=findViewById(R.id.stepsText);confidence=findViewById(R.id.confidenceText);String mode=getIntent().getStringExtra("mode");if(mode!=null&&!mode.isEmpty())device.setText(mode);findViewById(R.id.btnPhoto).setOnClickListener(v->choosePhotos());findViewById(R.id.btnNext).setOnClickListener(v->startDiagnosis());findViewById(R.id.qYes).setOnClickListener(v->answer(true));findViewById(R.id.qNo).setOnClickListener(v->answer(false));findViewById(R.id.btnSave).setOnClickListener(v->saveCurrent());}
    void choosePhotos(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,10);}
    void startDiagnosis(){String n=device.getText().toString().trim(),p=problem.getText().toString().trim();if(n.isEmpty()&&p.isEmpty()){Toast.makeText(this,"اكتب المشكلة أو اسم الجهاز أولًا",Toast.LENGTH_SHORT).show();return;}d=null;d=kb.find(n+" "+p);if(d==null){showUnknown();return;}qi=0;answers.clear();showQuestion();}
    void showUnknown(){questionBox.setVisibility(View.GONE);resultBox.setVisibility(View.VISIBLE);safety.setText("● نحتاج معلومات إضافية");safety.setTextColor(getColor(R.color.darik_warning));confidence.setText("المطابقة: منخفضة");result.setText("لم أجد سببًا موثوقًا بما يكفي. اكتب العرض الأساسي، مثل: لا يعمل، تسريب، صوت، حرارة، ضعف تبريد، أو أضف صورة واضحة.");tools.setText("المفيد الآن\n• اسم الجهاز أو مكان المشكلة\n• الماركة والموديل إن وُجدا\n• صورة عامة وصورة قريبة للمشكلة");steps.setText("دارك لا يخمن عطلًا خطيرًا عندما تكون المعلومات غير كافية. جرّب وصفًا أدق ثم أعد التشخيص.");findViewById(R.id.btnSave).setVisibility(View.VISIBLE);}
    void showQuestion(){if(qi>=d.questions.size()){finishDiagnosis();return;}questionBox.setVisibility(View.VISIBLE);resultBox.setVisibility(View.GONE);qTitle.setText("السؤال "+(qi+1)+" من "+d.questions.size());qBody.setText(d.questions.get(qi));}
    void answer(boolean yes){answers.add(yes);if(d.danger&&yes&&isDangerQuestion(d.questions.get(qi))){dangerStop();return;}qi++;showQuestion();}
    boolean isDangerQuestion(String q){String s=q.toLowerCase(Locale.ROOT);return s.contains("حرق")||s.contains("شرر")||s.contains("سخونة")||s.contains("فرقعة")||s.contains("رائحة");}
    void dangerStop(){questionBox.setVisibility(View.GONE);resultBox.setVisibility(View.VISIBLE);safety.setText("⚠ خطر مرتفع — توقف");safety.setTextColor(getColor(R.color.darik_danger));confidence.setText("قرار السلامة: إيقاف الإصلاح الذاتي");result.setText("ظهرت علامة خطر. لا تفتح الجهاز ولا تواصل الإصلاح الذاتي.");tools.setText("الأدوات\n• لا توجد أدوات مقترحة للإصلاح الذاتي في هذه الحالة.");steps.setText("الآن\n1. أوقف الاستخدام.\n2. إذا كان فصل الطاقة آمنًا فافصلها فقط.\n3. لا تفتح اللوحة أو الجهاز.\n4. اطلب فحصًا مؤهلًا عند الحاجة.");findViewById(R.id.btnSave).setVisibility(View.VISIBLE);}
    void finishDiagnosis(){questionBox.setVisibility(View.GONE);resultBox.setVisibility(View.VISIBLE); ImageView illustration=findViewById(R.id.diagnosisIllustration); if(illustration!=null){String label=(d.name+" "+d.category).toLowerCase(Locale.ROOT); int art=R.drawable.ill_repair_home; if(label.contains("غس")||label.contains("غسيل"))art=R.drawable.ill_washing_machine; else if(label.contains("مكيف")||label.contains("تبريد")||label.contains("ثلاج"))art=R.drawable.ill_air_conditioner; else if(label.contains("حنفي")||label.contains("سباك")||label.contains("مياه")||label.contains("مصرف"))art=R.drawable.ill_plumbing; else if(label.contains("كهرب")||label.contains("مقبس")||label.contains("قاطع")||label.contains("مصباح"))art=R.drawable.ill_electricity; else if(label.contains("فرن")||label.contains("ميكروويف")||label.contains("مطبخ"))art=R.drawable.ill_oven; else if(label.contains("تلفزيون")||label.contains("الكترون"))art=R.drawable.ill_television; illustration.setImageResource(art);}int yes=0;for(Boolean x:answers)if(x)yes++;int pct=Math.min(96,d.baseConfidence+yes*7+(images.isEmpty()?0:6));int risk=(d.danger?2:(yes>=3?1:0));safety.setText(risk==2?"⚠ خطر مرتفع — لا تصلح ذاتيًا":risk==1?"⚠ يحتاج حذرًا": "✓ منخفض الخطورة مبدئيًا");safety.setTextColor(getColor(risk==2?R.color.darik_danger:risk==1?R.color.darik_warning:R.color.darik_success));confidence.setText("مؤشر أولي غير مؤكد: "+pct+"%  •  "+images.size()+" صورة");StringBuilder r=new StringBuilder();r.append("السبب/الأسباب الأكثر احتمالًا\n");for(int i=0;i<d.diagnoses.size();i++)r.append(i+1).append(". ").append(d.diagnoses.get(i)).append("\n");result.setText(r.toString());StringBuilder t=new StringBuilder("الأدوات والمستلزمات\n");for(String x:d.tools)t.append("• ").append(x).append("\n");tools.setText(t.length()>10?t.toString():"لا توجد أدوات ضرورية في الخطوات الآمنة الأولى.");StringBuilder s=new StringBuilder("خطة الإصلاح الآمنة\n");for(int i=0;i<d.steps.size();i++)s.append(i+1).append(". ").append(d.steps.get(i)).append("\n");steps.setText(s.toString());findViewById(R.id.btnSave).setVisibility(View.VISIBLE);}
    void saveCurrent(){
        String name=d!=null?d.name:device.getText().toString().trim();
        if(name.isEmpty()) name="مشكلة منزلية";
        String desc=problem.getText().toString().trim();
        StringBuilder savedSummary = new StringBuilder();
        if (!desc.isEmpty()) savedSummary.append("وصف المشكلة: ").append(desc).append("\n\n");
        if (result != null && result.getText() != null && result.getText().length() > 0) {
            savedSummary.append(result.getText().toString().trim());
        }
        if (steps != null && steps.getText() != null && steps.getText().length() > 0) {
            if (savedSummary.length() > 0) savedSummary.append("\n\n");
            savedSummary.append(steps.getText().toString().trim());
        }
        if (savedSummary.length() == 0) savedSummary.append("تم حفظ التشخيص");
        RepairStore store=new RepairStore(this);
        ArrayList<String> savedUris=new ArrayList<>();
        for(Uri u:images) if(u!=null) savedUris.add(u.toString());
        store.saveRepair(name,savedSummary.toString(),savedUris);
        Toast.makeText(this,"تم حفظ نتيجة التشخيص والصور ("+savedUris.size()+") في إصلاحاتي.",Toast.LENGTH_LONG).show();
    }
    @Override protected void onActivityResult(int r,int c,Intent data){
        super.onActivityResult(r,c,data);
        if(r!=10||c!=RESULT_OK||data==null)return;
        images.clear();
        try{
            if(data.getClipData()!=null){
                for(int i=0;i<data.getClipData().getItemCount()&&i<5;i++){
                    Uri saved=copyImageToInternal(data.getClipData().getItemAt(i).getUri());
                    if(saved!=null)images.add(saved);
                }
            }else if(data.getData()!=null){
                Uri saved=copyImageToInternal(data.getData());
                if(saved!=null)images.add(saved);
            }
        }catch(Exception e){ photoStatus.setText("تعذر حفظ إحدى الصور. جرّب اختيار صورة أخرى."); }
        renderPhotoPreviews();
    }

    private Uri copyImageToInternal(Uri source){
        if(source==null)return null;
        File dir=new File(getFilesDir(),"repair_photos");
        if(!dir.exists()&&!dir.mkdirs())return null;
        String mime=getContentResolver().getType(source);
        String ext="image/png".equalsIgnoreCase(mime)?".png":("image/webp".equalsIgnoreCase(mime)?".webp":".jpg");
        File target=new File(dir,"photo_"+System.currentTimeMillis()+"_"+UUID.randomUUID().toString().substring(0,8)+ext);
        try(InputStream in=getContentResolver().openInputStream(source); OutputStream out=new FileOutputStream(target)){
            if(in==null){ target.delete(); return null; }
            byte[] buffer=new byte[8192]; int n; long total=0;
            while((n=in.read(buffer))!=-1){ total+=n; if(total>25L*1024*1024) throw new IOException("Image too large"); out.write(buffer,0,n); }
            out.flush();
            if(target.length()==0) throw new IOException("Empty image");
            return Uri.fromFile(target);
        }catch(Exception e){ if(target.exists())target.delete(); return null; }
    }

    void renderPhotoPreviews(){
        photosPreview.removeAllViews();
        for(Uri u:images){
            ImageView image=new ImageView(this);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(88),dp(88));
            lp.setMargins(dp(4),dp(4),dp(8),dp(4)); image.setLayoutParams(lp);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackgroundResource(R.drawable.bg_card);
            image.setContentDescription("صورة الجهاز المرفوعة");
            Bitmap bitmap=null;
            bitmap=PhotoLoader.decode(this,u,320);
            if(bitmap!=null) image.setImageBitmap(bitmap); else image.setImageURI(u);
            if(bitmap==null) image.setContentDescription("تعذر عرض الصورة؛ جرّب اختيارها مرة أخرى");
            photosPreview.addView(image);
        }
        photosScroll.setVisibility(images.isEmpty()?View.GONE:View.VISIBLE);
        photoStatus.setText(images.isEmpty()?"لم تُحفظ أي صورة. تحقق من صلاحية الوصول وحاول مجددًا.":"تم حفظ "+images.size()+" صورة داخل التطبيق — تظهر المعاينة أدناه");
    }
    private int dp(int value){return (int)(value*getResources().getDisplayMetrics().density+0.5f);}
}
