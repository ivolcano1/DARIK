package com.darik.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** A searchable index of the offline repair library. */
public class GuideActivity extends AppCompatActivity {
    private KnowledgeBase knowledge;
    private EditText search;
    private LinearLayout chips, results;
    private TextView count;
    private String selectedCategory = "الكل";
    private final List<String> categories = new ArrayList<>();

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        knowledge = new KnowledgeBase(this);
        buildScreen();
        Set<String> values = new LinkedHashSet<>();
        for (KnowledgeBase.Device device : knowledge.all()) values.add(device.category);
        categories.add("الكل");
        categories.addAll(values);
        renderChips();
        renderResults();
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { renderResults(); }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(16), dp(12), dp(16), dp(8));
        root.setBackgroundColor(Color.rgb(242, 246, 252));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView back = text("›", 34, true, Color.rgb(23, 105, 224));
        back.setGravity(Gravity.CENTER);
        back.setBackgroundResource(R.drawable.bg_icon_circle);
        toolbar.addView(back, new LinearLayout.LayoutParams(dp(46), dp(46)));
        back.setOnClickListener(v -> finish());
        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(dp(12), 0, 0, 0);
        TextView title = text("دليل الأعطال", 22, true, Color.rgb(16, 43, 80));
        TextView subtitle = text("حلول منزلية تعمل دون اتصال بالإنترنت", 12, false, Color.rgb(99, 117, 141));
        titleBox.addView(title);
        titleBox.addView(subtitle);
        toolbar.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(toolbar);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextDirection(View.TEXT_DIRECTION_RTL);
        search.setHint("ابحث باسم الجهاز أو العطل أو العرض…");
        search.setTextSize(14);
        search.setPadding(dp(14), 0, dp(14), 0);
        search.setBackgroundResource(R.drawable.bg_search);
        search.setCompoundDrawablePadding(dp(8));
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(-1, dp(54));
        searchParams.setMargins(0, dp(14), 0, dp(12));
        root.addView(search, searchParams);

        HorizontalScrollView chipScroll = new HorizontalScrollView(this);
        chipScroll.setHorizontalScrollBarEnabled(false);
        chipScroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        chipScroll.addView(chips);
        root.addView(chipScroll, new LinearLayout.LayoutParams(-1, dp(42)));

        count = text("", 12, true, Color.rgb(99, 117, 141));
        count.setPadding(dp(2), dp(14), dp(2), dp(8));
        root.addView(count);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        results.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(results);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void renderChips() {
        if (chips == null) return;
        chips.removeAllViews();
        for (String category : categories) {
            TextView chip = text(category, 12, category.equals(selectedCategory),
                category.equals(selectedCategory) ? Color.rgb(23, 105, 224) : Color.rgb(35, 52, 77));
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(13), 0, dp(13), 0);
            chip.setBackgroundResource(category.equals(selectedCategory) ? R.drawable.bg_tint_blue : R.drawable.bg_card);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(36));
            params.setMargins(dp(3), dp(2), dp(3), dp(2));
            chips.addView(chip, params);
            chip.setOnClickListener(v -> {
                selectedCategory = category;
                renderChips();
                renderResults();
            });
        }
    }

    private void renderResults() {
        if (results == null || knowledge == null) return;
        results.removeAllViews();
        String query = KnowledgeBase.normalize(search == null ? "" : search.getText().toString());
        int shown = 0;
        for (KnowledgeBase.Device device : knowledge.all()) {
            if (!"الكل".equals(selectedCategory) && !selectedCategory.equals(device.category)) continue;
            String haystack = KnowledgeBase.normalize(device.name + " " + device.category + " " +
                joinStrings(device.keywords) + " " + joinStrings(device.symptoms) + " " + joinStrings(device.diagnoses));
            if (!query.isEmpty() && !haystack.contains(query) && !allTokensMatch(query, haystack)) continue;
            results.addView(makeCard(device));
            shown++;
        }
        count.setText("عرض " + shown + " من " + knowledge.all().size() + " حالة");
        if (shown == 0) {
            TextView empty = text("لم نعثر على نتيجة بهذا الوصف. جرّب اسم الجهاز أو كلمة أبسط مثل: تسريب، اهتزاز، تبريد، أو تصريف.", 14, false, Color.rgb(99, 117, 141));
            empty.setPadding(dp(18), dp(20), dp(18), dp(20));
            empty.setBackgroundResource(R.drawable.bg_card);
            results.addView(empty);
        }
    }

    private String joinStrings(List<String> values) {
        StringBuilder joined = new StringBuilder();
        for (String value : values) joined.append(value).append(' ');
        return joined.toString();
    }

    private boolean allTokensMatch(String query, String haystack) {
        String[] tokens = query.split(" ");
        int matched = 0, meaningful = 0;
        for (String token : tokens) {
            if (token.length() < 2) continue;
            meaningful++;
            if (haystack.contains(token)) matched++;
        }
        return meaningful > 1 && matched == meaningful;
    }

    private View makeCard(KnowledgeBase.Device device) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackgroundResource(R.drawable.bg_card);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.setMargins(0, 0, 0, dp(10));
        card.setLayoutParams(cardParams);
        card.setElevation(dp(1));

        LinearLayout firstRow = new LinearLayout(this);
        firstRow.setGravity(Gravity.CENTER_VERTICAL);
        firstRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView icon = text("⌂", 22, true, Color.rgb(23, 105, 224));
        icon.setGravity(Gravity.CENTER);
        icon.setBackgroundResource(R.drawable.bg_tint_blue);
        firstRow.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout words = new LinearLayout(this);
        words.setOrientation(LinearLayout.VERTICAL);
        words.setPadding(dp(10), 0, 0, 0);
        TextView name = text(device.name, 15, true, Color.rgb(20, 35, 60));
        TextView category = text(device.category, 11, false, Color.rgb(99, 117, 141));
        words.addView(name);
        words.addView(category);
        firstRow.addView(words, new LinearLayout.LayoutParams(0, -2, 1));
        if (device.danger) {
            TextView warning = text("حذر", 10, true, Color.rgb(154, 87, 0));
            warning.setPadding(dp(8), dp(5), dp(8), dp(5));
            warning.setBackgroundResource(R.drawable.bg_tint_orange);
            firstRow.addView(warning);
        }
        card.addView(firstRow);

        if (!device.diagnoses.isEmpty()) {
            TextView summary = text("أمثلة للأسباب: " + device.diagnoses.get(0), 12, false, Color.rgb(72, 88, 111));
            summary.setPadding(0, dp(10), 0, dp(3));
            card.addView(summary);
        }
        TextView details = text(device.questions.size() + " أسئلة تشخيصية  •  " + device.steps.size() + " خطوات إرشادية", 11, false, Color.rgb(99, 117, 141));
        card.addView(details);
        TextView action = text("افتح التشخيص  ←", 12, true, Color.rgb(23, 105, 224));
        action.setGravity(Gravity.RIGHT);
        action.setPadding(0, dp(10), 0, 0);
        card.addView(action);
        card.setClickable(true);
        card.setFocusable(true);
        card.setOnClickListener(v -> {
            Intent intent = new Intent(this, DiagnosisActivity.class);
            intent.putExtra("mode", device.name);
            startActivity(intent);
        });
        return card;
    }

    private TextView text(String value, int size, boolean bold, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTextDirection(View.TEXT_DIRECTION_RTL);
        if (bold) view.setTypeface(null, Typeface.BOLD);
        return view;
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
