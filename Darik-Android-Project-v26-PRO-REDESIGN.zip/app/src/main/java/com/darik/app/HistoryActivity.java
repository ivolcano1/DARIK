package com.darik.app;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Saved repair results with local photo previews and per-record deletion. */
public class HistoryActivity extends AppCompatActivity {
    private LinearLayout list;
    private RepairStore store;
    private TextView count;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        store = new RepairStore(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(16), dp(12), dp(16), dp(8));
        root.setBackgroundColor(Color.rgb(242, 246, 252));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView back = text("›", 34, true, Color.rgb(23, 105, 224));
        back.setGravity(Gravity.CENTER);
        back.setBackgroundResource(R.drawable.bg_icon_circle);
        toolbar.addView(back, new LinearLayout.LayoutParams(dp(46), dp(46)));
        back.setOnClickListener(v -> finish());
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(12), 0, 0, 0);
        titles.addView(text("إصلاحاتي", 22, true, Color.rgb(16, 43, 80)));
        titles.addView(text("نتائج التشخيص والصور التي حفظتها", 12, false, Color.rgb(99, 117, 141)));
        toolbar.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(toolbar);

        LinearLayout listHeader = new LinearLayout(this);
        listHeader.setGravity(Gravity.CENTER_VERTICAL);
        listHeader.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView section = text("السجل المحفوظ", 17, true, Color.rgb(20, 35, 60));
        listHeader.addView(section, new LinearLayout.LayoutParams(0, -2, 1));
        count = text("0 نتيجة", 12, true, Color.rgb(99, 117, 141));
        listHeader.addView(count);
        LinearLayout.LayoutParams sectionParams = new LinearLayout.LayoutParams(-1, -2);
        sectionParams.setMargins(0, dp(15), 0, dp(7));
        root.addView(listHeader, sectionParams);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        list.setPadding(0, dp(3), 0, dp(12));
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
        getWindow().setStatusBarColor(Color.rgb(242, 246, 252));
        getWindow().setNavigationBarColor(Color.rgb(242, 246, 252));
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        if (list != null && store != null) refresh();
    }

    private void refresh() {
        list.removeAllViews();
        List<RepairStore.RepairRecord> records = store.records();
        count.setText(records.size() + (records.size() == 1 ? " نتيجة" : " نتائج"));
        if (records.isEmpty()) {
            LinearLayout empty = new LinearLayout(this);
            empty.setOrientation(LinearLayout.VERTICAL);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(22), dp(34), dp(22), dp(34));
            empty.setBackgroundResource(R.drawable.bg_card);
            TextView icon = text("◷", 34, true, Color.rgb(23, 105, 224));
            icon.setGravity(Gravity.CENTER);
            empty.addView(icon);
            TextView title = text("لا توجد إصلاحات محفوظة بعد", 16, true, Color.rgb(20, 35, 60));
            title.setGravity(Gravity.CENTER);
            title.setPadding(0, dp(10), 0, dp(5));
            empty.addView(title);
            TextView subtitle = text("ابدأ تشخيص عطل من الصفحة الرئيسية، ثم احفظ النتيجة لتظهر هنا مع الصور التي أرفقتها.", 12, false, Color.rgb(99, 117, 141));
            subtitle.setGravity(Gravity.CENTER);
            empty.addView(subtitle);
            list.addView(empty, new LinearLayout.LayoutParams(-1, -2));
            return;
        }
        for (RepairStore.RepairRecord record : records) list.addView(makeCard(record));
    }

    private View makeCard(RepairStore.RepairRecord record) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setPadding(dp(14), dp(13), dp(14), dp(13));
        card.setBackgroundResource(R.drawable.bg_card);
        card.setElevation(dp(1));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.setMargins(0, 0, 0, dp(11));
        card.setLayoutParams(cardParams);

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        heading.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView icon = text("◷", 20, true, Color.rgb(23, 105, 224));
        icon.setGravity(Gravity.CENTER);
        icon.setBackgroundResource(R.drawable.bg_tint_blue);
        heading.addView(icon, new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setPadding(dp(10), 0, 0, 0);
        TextView device = text(record.device, 15, true, Color.rgb(20, 35, 60));
        TextView date = text(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, new Locale("ar"))
            .format(new Date(record.time)), 10, false, Color.rgb(99, 117, 141));
        labels.addView(device);
        labels.addView(date);
        heading.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
        TextView delete = text("حذف", 12, true, Color.rgb(180, 35, 24));
        delete.setPadding(dp(8), dp(8), dp(8), dp(8));
        heading.addView(delete);
        delete.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("حذف الإصلاح")
            .setMessage("سيتم حذف هذه النتيجة والصور المرتبطة بها من السجل. هل تريد المتابعة؟")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حذف", (dialog, which) -> {
                store.deleteRepair(record.storageIndex);
                refresh();
                Toast.makeText(this, "تم حذف السجل", Toast.LENGTH_SHORT).show();
            }).show());
        card.addView(heading);

        if (record.result != null && !record.result.trim().isEmpty()) {
            TextView summary = text(record.result.trim(), 12, false, Color.rgb(72, 88, 111));
            summary.setMaxLines(4);
            summary.setEllipsize(TextUtils.TruncateAt.END);
            summary.setPadding(0, dp(11), 0, dp(3));
            card.addView(summary);
            TextView details = text("عرض التفاصيل الكاملة  ←", 12, true, Color.rgb(23, 105, 224));
            details.setGravity(Gravity.RIGHT);
            details.setPadding(0, dp(6), 0, dp(4));
            card.addView(details);
            details.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle(record.device)
                .setMessage(record.result)
                .setPositiveButton("إغلاق", null)
                .show());
            summary.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle(record.device)
                .setMessage(record.result)
                .setPositiveButton("إغلاق", null)
                .show());
        }

        if (!record.images.isEmpty()) {
            HorizontalScrollView horizontal = new HorizontalScrollView(this);
            horizontal.setHorizontalScrollBarEnabled(false);
            horizontal.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            LinearLayout thumbnails = new LinearLayout(this);
            thumbnails.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            thumbnails.setOrientation(LinearLayout.HORIZONTAL);
            for (String uriText : record.images) {
                try {
                    Uri uri = Uri.parse(uriText);
                    ImageView image = new ImageView(this);
                    image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    image.setBackgroundResource(R.drawable.bg_tint_blue);
                    LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(dp(88), dp(88));
                    imageParams.setMargins(0, dp(4), dp(8), dp(4));
                    thumbnails.addView(image, imageParams);
                    Bitmap bitmap = PhotoLoader.decode(this, uri, 640);
                    if (bitmap != null) image.setImageBitmap(bitmap);
                    else image.setContentDescription("تعذر تحميل الصورة المحفوظة");
                    image.setContentDescription("افتح الصورة المحفوظة");
                    image.setOnClickListener(v -> showPhoto(uri));
                } catch (Exception ignored) { }
            }
            horizontal.addView(thumbnails);
            LinearLayout.LayoutParams photoParams = new LinearLayout.LayoutParams(-1, -2);
            photoParams.setMargins(0, dp(8), 0, 0);
            card.addView(horizontal, photoParams);
        }
        return card;
    }

    private void showPhoto(Uri uri) {
        Bitmap bitmap = PhotoLoader.decode(this, uri, 1400);
        if (bitmap == null) {
            Toast.makeText(this, "تعذر فتح الصورة المحفوظة", Toast.LENGTH_SHORT).show();
            return;
        }
        ImageView image = new ImageView(this);
        image.setImageBitmap(bitmap);
        image.setAdjustViewBounds(true);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        new AlertDialog.Builder(this).setView(image).setPositiveButton("إغلاق", null).show();
    }

    private TextView text(String value, int size, boolean bold, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTextDirection(View.TEXT_DIRECTION_RTL);
        if (bold) view.setTypeface(null, Typeface.BOLD);
        return view;
    }
}
