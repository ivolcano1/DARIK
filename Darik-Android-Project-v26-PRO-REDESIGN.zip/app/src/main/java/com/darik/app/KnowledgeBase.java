package com.darik.app;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Offline Arabic knowledge base. Ambiguous descriptions deliberately return no result. */
public class KnowledgeBase {
    public static class Device {
        String name, category;
        boolean danger;
        int baseConfidence = 60;
        List<String> keywords = new ArrayList<>(), questions = new ArrayList<>(),
            diagnoses = new ArrayList<>(), tools = new ArrayList<>(), steps = new ArrayList<>(),
            symptoms = new ArrayList<>();
    }

    private final List<Device> devices = new ArrayList<>();
    private static final Set<String> STOP_WORDS = new HashSet<>(Arrays.asList(
        "لا", "لم", "لن", "ما", "مش", "مو", "ليس", "هل", "هو", "هي", "في", "من", "على", "عن", "الى", "إلى",
        "مع", "عند", "بعد", "قبل", "هذا", "هذه", "ذلك", "جدا", "جداً", "كان", "كانت", "يكون", "تكون",
        "يعمل", "تعمل", "عمل", "يشتغل", "تشتغل", "اشتغل", "شغال", "شغالة", "الجهاز", "جهاز", "شيء", "شي"
    ));

    public KnowledgeBase(Context context) {
        try (InputStream input = context.getAssets().open("knowledge.json")) {
            byte[] bytes = new byte[input.available()];
            int offset = 0;
            while (offset < bytes.length) {
                int read = input.read(bytes, offset, bytes.length - offset);
                if (read < 0) break;
                offset += read;
            }
            JSONArray array = new JSONObject(new String(bytes, StandardCharsets.UTF_8)).getJSONArray("devices");
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.getJSONObject(i);
                Device device = new Device();
                device.name = item.optString("name", "جهاز منزلي");
                device.category = item.optString("category", "عام");
                device.danger = item.optBoolean("danger", false);
                device.baseConfidence = Math.max(40, Math.min(90, item.optInt("baseConfidence", 60)));
                fill(item.optJSONArray("keywords"), device.keywords);
                fill(item.optJSONArray("questions"), device.questions);
                fill(item.optJSONArray("diagnoses"), device.diagnoses);
                fill(item.optJSONArray("tools"), device.tools);
                fill(item.optJSONArray("steps"), device.steps);
                fill(item.optJSONArray("symptoms"), device.symptoms);
                devices.add(device);
            }
        } catch (Exception e) {
            throw new IllegalStateException("تعذر تحميل قاعدة المعرفة المحلية", e);
        }
    }

    private void fill(JSONArray source, List<String> target) {
        if (source == null) return;
        for (int i = 0; i < source.length(); i++) {
            String value = source.optString(i, "").trim();
            if (!value.isEmpty()) target.add(value);
        }
    }

    public List<Device> all() { return Collections.unmodifiableList(devices); }

    public static String normalize(String value) {
        if (value == null) return "";
        String s = value.toLowerCase(Locale.ROOT).trim()
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
            .replace('ى', 'ي').replace('ة', 'ه').replace('ؤ', 'و').replace('ئ', 'ي')
            .replaceAll("[ًٌٍَُِّْـ]", "")
            .replaceAll("[^\\p{L}\\p{N} ]", " ")
            .replaceAll("\\s+", " ").trim();
        if (s.isEmpty()) return "";
        String[] parts = s.split(" ");
        StringBuilder clean = new StringBuilder();
        for (String token : parts) {
            // Treat common Arabic definite-article variants as the same word (الثلاجة/ثلاجة).
            if (token.length() > 4 && token.startsWith("ال")) token = token.substring(2);
            if (clean.length() > 0) clean.append(' ');
            clean.append(token);
        }
        return clean.toString();
    }

    private List<String> significantTokens(String value) {
        List<String> tokens = new ArrayList<>();
        for (String token : normalize(value).split(" ")) {
            if (token.length() >= 2 && !STOP_WORDS.contains(token)) tokens.add(token);
        }
        return tokens;
    }

    private int phraseScore(String query, String phrase, int exact, int contained, int partial) {
        String p = normalize(phrase);
        if (p.isEmpty()) return 0;
        if (query.equals(p)) return exact;
        if (query.contains(p)) return contained;
        if (p.contains(query) && query.length() >= 4) return partial;
        return 0;
    }

    private int bestPhraseScore(String query, List<String> phrases, int exact, int contained, int partial) {
        int best = 0;
        for (String phrase : phrases) best = Math.max(best, phraseScore(query, phrase, exact, contained, partial));
        return best;
    }

    private boolean tokenEquivalent(String queryToken, String candidateToken) {
        if (queryToken.equals(candidateToken)) return true;
        if (queryToken.length() < 3 || candidateToken.length() < 3) return false;
        return queryToken.startsWith(candidateToken) || candidateToken.startsWith(queryToken)
            || queryToken.contains(candidateToken) || candidateToken.contains(queryToken);
    }

    private boolean tokenInAny(String token, List<String> phrases) {
        for (String phrase : phrases) {
            for (String candidate : significantTokens(phrase)) {
                if (tokenEquivalent(token, candidate)) return true;
            }
        }
        return false;
    }

    public Device find(String description) {
        String query = normalize(description);
        if (query.isEmpty()) return null;

        // Exact device/fault names always win over keywords repeated on related records.
        for (Device device : devices) {
            if (query.equals(normalize(device.name))) return device;
        }

        List<String> queryTokens = significantTokens(query);
        // Generic descriptions like "لا يعمل" should ask the user for more detail instead of guessing.
        if (queryTokens.isEmpty()) return null;

        Device best = null;
        int bestScore = 0;
        int secondScore = 0;
        for (Device device : devices) {
            String name = normalize(device.name);
            int score = phraseScore(query, name, 100, 15, 6);
            score += bestPhraseScore(query, device.keywords, 38, 17, 4);
            score += bestPhraseScore(query, device.symptoms, 36, 20, 4);
            score += bestPhraseScore(query, device.diagnoses, 8, 5, 0);

            List<String> nameTokens = significantTokens(name);
            for (String token : queryTokens) {
                boolean nameMatch = false;
                for (String candidate : nameTokens) {
                    if (tokenEquivalent(token, candidate)) {
                        score += token.equals(candidate) ? 14 : 7;
                        nameMatch = true;
                        break;
                    }
                }
                if (!nameMatch && tokenInAny(token, device.keywords)) score += 4;
                if (tokenInAny(token, device.symptoms)) score += 6;
            }
            if (normalize(device.category).equals(query)) score += 2;
            if (score > bestScore) {
                secondScore = bestScore;
                bestScore = score;
                best = device;
            } else if (score > secondScore) {
                secondScore = score;
            }
        }
        // Require both a meaningful signal and a margin over the next candidate.
        return bestScore >= 12 && (bestScore - secondScore >= 6) ? best : null;
    }

}
