package com.darik.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import android.app.Dialog;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.FrameLayout;
import android.graphics.Typeface;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {
    private EditText search;
    private TextView history;
    private ScrollView homeScroll;
    private View searchWrap;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);

        MaterialButton start = findViewById(R.id.btnStart);
        TextView unknown = findViewById(R.id.btnUnknown);
        history = findViewById(R.id.historyText);
        search = findViewById(R.id.searchInput);
        homeScroll = findViewById(R.id.homeScroll);
        searchWrap = findViewById(R.id.searchWrap);

        updateCount();
        start.setOnClickListener(v -> submitSearch());
        search.setOnEditorActionListener((v, actionId, event) -> {
            submitSearch();
            return true;
        });
        findViewById(R.id.btnSearchSubmit).setOnClickListener(v -> submitSearch());
        unknown.setOnClickListener(v -> open(""));

        findViewById(R.id.btnTopSearch).setOnClickListener(v -> focusSearch());
        findViewById(R.id.btnMenu).setOnClickListener(v -> showMainMenu());
        findViewById(R.id.btnHistory).setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
        findViewById(R.id.btnDevices).setOnClickListener(v -> startActivity(new Intent(this, DevicesActivity.class)));
        findViewById(R.id.btnGuide).setOnClickListener(v -> startActivity(new Intent(this, GuideActivity.class)));

        bindCategory(R.id.catCooling, "مكيف");
        bindCategory(R.id.catFridge, "ثلاجة");
        bindCategory(R.id.catLaundry, "غسالة");
        bindCategory(R.id.catKitchen, "فرن كهربائي");
        bindCategory(R.id.catPlumbing, "حنفية");
        bindCategory(R.id.catElectric, "مفتاح كهرباء");
        bindCategory(R.id.catElectronics, "تلفزيون");
        bindCategory(R.id.catNetwork, "راوتر الإنترنت");
        bindCategory(R.id.catWater, "ضغط المياه ضعيف في المنزل");
        bindCategory(R.id.catCleaning, "مكنسة كهربائية");
        bindCategory(R.id.issueNoPower, "الجهاز لا يعمل");
        bindCategory(R.id.issueLeak, "تسريب مياه");
        bindCategory(R.id.issueNoise, "مروحة سقف تصدر صوتًا");
        bindCategory(R.id.issueCooling, "مكيف لا يبرد");
        bindCategory(R.id.issueDrain, "غسالة لا تصرف الماء");
        bindCategory(R.id.issueHeat, "سخان مياه");
        bindCategory(R.id.issuePowerTrip, "القاطع يفصل الكهرباء");
        bindCategory(R.id.issueVibration, "الغسالة تهتز بشدة");
        bindCategory(R.id.issueRouter, "راوتر الإنترنت");
        bindCategory(R.id.issueDoor, "باب لا يغلق جيدًا");
        bindCategory(R.id.issueLamp, "لمبة تومض");
        bindCategory(R.id.issuePressure, "ضغط المياه ضعيف في المنزل");
    }


    private void showMainMenu() {
        final Dialog dialog = new Dialog(this);
        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(Color.TRANSPARENT);

        LinearLayout drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        drawer.setPadding(dp(16), dp(18), dp(16), dp(14));
        drawer.setBackgroundColor(Color.WHITE);
        drawer.setElevation(dp(16));
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int drawerWidth = Math.min(dp(340), (int) (screenWidth * 0.86f));
        FrameLayout.LayoutParams drawerParams = new FrameLayout.LayoutParams(drawerWidth, -1, Gravity.RIGHT | Gravity.TOP);
        overlay.addView(drawer, drawerParams);
        drawer.setOnClickListener(v -> { /* Keep taps inside the drawer from dismissing it. */ });

        LinearLayout headingRow = new LinearLayout(this);
        headingRow.setOrientation(LinearLayout.HORIZONTAL);
        headingRow.setGravity(Gravity.CENTER_VERTICAL);
        headingRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ImageView brand = new ImageView(this);
        brand.setImageResource(R.drawable.ic_darik_logo);
        brand.setContentDescription("شعار دارك");
        headingRow.addView(brand, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout headingText = new LinearLayout(this);
        headingText.setOrientation(LinearLayout.VERTICAL);
        headingText.setPadding(dp(10), 0, 0, 0);
        TextView heading = new TextView(this);
        heading.setText("دارك");
        heading.setTextSize(21);
        heading.setTypeface(null, Typeface.BOLD);
        heading.setTextColor(Color.rgb(16, 43, 80));
        TextView subheading = new TextView(this);
        subheading.setText("صيانة بيتك خطوة بخطوة");
        subheading.setTextSize(11);
        subheading.setTextColor(Color.rgb(95, 110, 130));
        headingText.addView(heading);
        headingText.addView(subheading);
        headingRow.addView(headingText, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = new TextView(this);
        close.setText("×");
        close.setTextSize(28);
        close.setTextColor(Color.rgb(95, 110, 130));
        close.setGravity(Gravity.CENTER);
        close.setContentDescription("إغلاق القائمة");
        headingRow.addView(close, new LinearLayout.LayoutParams(dp(38), dp(42)));
        drawer.addView(headingRow, new LinearLayout.LayoutParams(-1, -2));
        close.setOnClickListener(v -> dismissDrawer(dialog, drawer, null));

        addDivider(drawer, 14, 12);
        addMenuRow(drawer, "⌂", "الرئيسية", () -> {
            homeScroll.smoothScrollTo(0, 0);
            search.clearFocus();
        }, dialog);
        addMenuRow(drawer, "⌕", "ابدأ التشخيص", () -> focusSearch(), dialog);
        addMenuRow(drawer, "▤", "دليل الأعطال", () -> startActivity(new Intent(this, GuideActivity.class)), dialog);
        addMenuRow(drawer, "▦", "أجهزتي", () -> startActivity(new Intent(this, DevicesActivity.class)), dialog);
        addMenuRow(drawer, "◷", "إصلاحاتي", () -> startActivity(new Intent(this, HistoryActivity.class)), dialog);
        addMenuRow(drawer, "⚙", "الإعدادات والخصوصية", () -> startActivity(new Intent(this, SettingsActivity.class)), dialog);
        addMenuRow(drawer, "◇", "السلامة أولًا", () -> showSafetyDialog(), dialog);

        addDivider(drawer, 14, 8);
        TextView note = new TextView(this);
        note.setText("بحث محلي • دون اتصال أو ذكاء اصطناعي\nالإصدار 26.0.0");
        note.setTextSize(12);
        note.setLineSpacing(dp(3), 1f);
        note.setGravity(Gravity.CENTER);
        note.setTextColor(Color.rgb(95, 110, 130));
        note.setPadding(dp(8), dp(6), dp(8), dp(4));
        drawer.addView(note, new LinearLayout.LayoutParams(-1, -2));

        overlay.setOnClickListener(v -> dismissDrawer(dialog, drawer, null));
        dialog.setContentView(overlay);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams attrs = window.getAttributes();
            attrs.width = WindowManager.LayoutParams.MATCH_PARENT;
            attrs.height = WindowManager.LayoutParams.MATCH_PARENT;
            attrs.gravity = Gravity.TOP | Gravity.RIGHT;
            attrs.dimAmount = 0.42f;
            window.setAttributes(attrs);
        }
        dialog.show();
        if (window != null) window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        drawer.post(() -> {
            drawer.setTranslationX(drawer.getWidth());
            drawer.animate().translationX(0f).setDuration(220).start();
        });
    }

    private void addDivider(LinearLayout parent, int top, int bottom) {
        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(225, 232, 242));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(1));
        params.setMargins(0, dp(top), 0, dp(bottom));
        parent.addView(divider, params);
    }

    private void dismissDrawer(Dialog dialog, View drawer, Runnable afterClose) {
        if (drawer == null || drawer.getWidth() == 0) {
            dialog.dismiss();
            if (afterClose != null) afterClose.run();
            return;
        }
        drawer.animate().translationX(drawer.getWidth()).setDuration(160).withEndAction(() -> {
            dialog.dismiss();
            if (afterClose != null) afterClose.run();
        }).start();
    }

    private void showSafetyDialog() {
        new AlertDialog.Builder(this)
            .setTitle("السلامة أولًا")
            .setMessage("أوقف الجهاز عند وجود شرر أو رائحة احتراق أو تسريب غاز. لا تفتح الأجهزة أو التوصيلات الخطرة بنفسك. افصل الطاقة فقط إذا كان ذلك آمنًا، وابتعد عن الماء القريب من الكهرباء. عند الاشتباه بتسريب غاز، لا تشغّل مفاتيح أو لهبًا، وغادر المكان واتصل بجهة الطوارئ أو الغاز من مكان آمن.")
            .setPositiveButton("حسنًا", null).show();
    }

    private void addMenuRow(LinearLayout drawer, String symbol, String label, Runnable action, Dialog dialog) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setPadding(dp(10), 0, dp(10), 0);
        row.setBackgroundResource(R.drawable.bg_card);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, dp(49));
        rowParams.setMargins(0, dp(3), 0, dp(3));
        drawer.addView(row, rowParams);
        TextView icon = new TextView(this);
        icon.setText(symbol);
        icon.setTextSize(22);
        icon.setTextColor(Color.rgb(30, 100, 190));
        icon.setGravity(Gravity.CENTER);
        row.addView(icon, new LinearLayout.LayoutParams(dp(38), -1));
        TextView title = new TextView(this);
        title.setText(label);
        title.setTextSize(15);
        title.setTextColor(Color.rgb(25, 42, 66));
        title.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        row.addView(title, new LinearLayout.LayoutParams(0, -1, 1));
        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(v -> dismissDrawer(dialog, drawer, action));
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void focusSearch() {
        homeScroll.smoothScrollTo(0, Math.max(0, searchWrap.getTop()));
        search.requestFocus();
        search.post(() -> {
            InputMethodManager keyboard = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (keyboard != null) keyboard.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT);
        });
    }

    private void bindCategory(int id, String query) {
        View view = findViewById(id);
        if (view != null) view.setOnClickListener(v -> open(query));
    }

    private void open(String mode) {
        Intent intent = new Intent(this, DiagnosisActivity.class);
        intent.putExtra("mode", mode == null ? "" : mode);
        startActivity(intent);
    }

    private void submitSearch() {
        String query = search.getText().toString().trim();
        if (query.isEmpty()) {
            Toast.makeText(this, "اكتب اسم الجهاز أو وصف العطل أولًا", Toast.LENGTH_SHORT).show();
            focusSearch();
            return;
        }
        open(query);
    }

    private void updateCount() {
        if (history != null) history.setText(new RepairStore(this).count() + " عملية محفوظة");
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCount();
    }
}
