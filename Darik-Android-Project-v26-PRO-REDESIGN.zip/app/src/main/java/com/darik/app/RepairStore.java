package com.darik.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.DateFormat;
import android.net.Uri;
import java.io.File;
import java.util.*;

public class RepairStore {
    private final SharedPreferences p;
    private final Context appContext;
    public RepairStore(Context c){ appContext=c.getApplicationContext(); p=appContext.getSharedPreferences("darik_store",Context.MODE_PRIVATE); }
    public static class RepairRecord {
        public int storageIndex;
        public String device = "مشكلة منزلية";
        public String result = "";
        public long time;
        public List<String> images = new ArrayList<>();
    }

    /** Returns saved repairs newest-first while retaining the original stored index for safe deletion. */
    public List<RepairRecord> records() {
        List<RepairRecord> out = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(p.getString("repairs", "[]"));
            for (int i = array.length() - 1; i >= 0; i--) {
                JSONObject item = array.getJSONObject(i);
                RepairRecord record = new RepairRecord();
                record.storageIndex = i;
                record.device = item.optString("device", "مشكلة منزلية");
                record.result = item.optString("result", "");
                record.time = item.optLong("time", 0L);
                JSONArray photos = item.optJSONArray("images");
                if (photos != null) for (int j = 0; j < photos.length(); j++) {
                    String uri = photos.optString(j, "");
                    if (!uri.isEmpty()) record.images.add(uri);
                }
                out.add(record);
            }
        } catch (Exception ignored) { }
        return out;
    }

    public void deleteRepair(int storageIndex) {
        try {
            JSONArray old = new JSONArray(p.getString("repairs", "[]"));
            if (storageIndex < 0 || storageIndex >= old.length()) return;
            JSONObject removed = old.getJSONObject(storageIndex);
            deleteRecordPhotos(removed.optJSONArray("images"));
            JSONArray kept = new JSONArray();
            for (int i = 0; i < old.length(); i++) if (i != storageIndex) kept.put(old.getJSONObject(i));
            p.edit().putString("repairs", kept.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void deleteRecordPhotos(JSONArray photos) {
        if (photos == null) return;
        try {
            File allowedDir = new File(appContext.getFilesDir(), "repair_photos").getCanonicalFile();
            for (int i = 0; i < photos.length(); i++) {
                Uri uri = Uri.parse(photos.optString(i, ""));
                if (!"file".equalsIgnoreCase(uri.getScheme()) || uri.getPath() == null) continue;
                File file = new File(uri.getPath()).getCanonicalFile();
                if (file.getPath().startsWith(allowedDir.getPath() + File.separator) && file.isFile()) file.delete();
            }
        } catch (Exception ignored) { }
    }

    public void saveRepair(String device,String result){ saveRepair(device,result,Collections.emptyList()); }
    public void saveRepair(String device,String result,List<String> imageUris){
        try{ JSONArray a=new JSONArray(p.getString("repairs","[]")); JSONObject o=new JSONObject();
            o.put("device",device); o.put("result",result); o.put("time",System.currentTimeMillis());
            JSONArray photos=new JSONArray(); if(imageUris!=null) for(String uri:imageUris) photos.put(uri); o.put("images",photos); a.put(o);
            p.edit().putString("repairs",a.toString()).apply();
        }catch(Exception ignored){}
    }
    public List<List<String>> repairImages(){
        List<List<String>> out=new ArrayList<>();
        try{JSONArray a=new JSONArray(p.getString("repairs","[]")); for(int i=a.length()-1;i>=0;i--){JSONObject o=a.getJSONObject(i);JSONArray photos=o.optJSONArray("images");List<String> row=new ArrayList<>();if(photos!=null)for(int j=0;j<photos.length();j++)row.add(photos.optString(j));out.add(row);}}
        catch(Exception ignored){} return out;
    }

    /** Deletes only photo files referenced by saved repair records, then clears the history. */
    public void clearRepairs() {
        try {
            JSONArray repairs = new JSONArray(p.getString("repairs", "[]"));
            for (int i = 0; i < repairs.length(); i++) deleteRecordPhotos(repairs.getJSONObject(i).optJSONArray("images"));
        } catch (Exception ignored) { }
        p.edit().remove("repairs").apply();
    }

    public int count(){ try{return new JSONArray(p.getString("repairs","[]")).length();}catch(Exception e){return 0;} }
    public List<String> summaries(){
        List<String> out=new ArrayList<>();
        try{ JSONArray a=new JSONArray(p.getString("repairs","[]"));
            for(int i=a.length()-1;i>=0;i--){ JSONObject o=a.getJSONObject(i); Date d=new Date(o.optLong("time"));
                out.add(o.optString("device","مشكلة منزلية")+"\n"+o.optString("result","")+"\n"+DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(d)); }
        }catch(Exception ignored){}
        return out;
    }
    public void saveDevice(String name,String model){
        if(name==null||name.trim().isEmpty()) return;
        String cleanName=name.trim(); String cleanModel=model==null?"":model.trim();
        try{
            JSONArray old=new JSONArray(p.getString("devices","[]")); JSONArray kept=new JSONArray();
            for(int i=0;i<old.length();i++){
                JSONObject item=old.getJSONObject(i);
                if(cleanName.equalsIgnoreCase(item.optString("name").trim()) && cleanModel.equalsIgnoreCase(item.optString("model").trim())) continue;
                kept.put(item);
            }
            JSONObject o=new JSONObject(); o.put("name",cleanName);o.put("model",cleanModel);o.put("time",System.currentTimeMillis());kept.put(o);
            p.edit().putString("devices",kept.toString()).apply();
        }catch(Exception ignored){}
    }

    public void deleteDevice(String device) {
        try {
            JSONArray old = new JSONArray(p.getString("devices", "[]"));
            JSONArray kept = new JSONArray();
            boolean removed = false;
            for (int i = 0; i < old.length(); i++) {
                JSONObject o = old.getJSONObject(i);
                String label = o.optString("name") + (o.optString("model").isEmpty() ? "" : " — " + o.optString("model"));
                if (!removed && label.equals(device)) { removed = true; continue; }
                kept.put(o);
            }
            p.edit().putString("devices", kept.toString()).apply();
        } catch (Exception ignored) {}
    }

    public List<String> devices(){
        List<String> out=new ArrayList<>(); try{JSONArray a=new JSONArray(p.getString("devices","[]")); for(int i=a.length()-1;i>=0;i--){JSONObject o=a.getJSONObject(i);out.add(o.optString("name")+(o.optString("model").isEmpty()?"":" — "+o.optString("model")));}}catch(Exception ignored){} return out;
    }
}
