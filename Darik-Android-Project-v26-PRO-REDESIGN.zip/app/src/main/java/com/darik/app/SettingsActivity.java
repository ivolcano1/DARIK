package com.darik.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

/** Settings for the offline-first app; no account, tracking or AI connection is used. */
public class SettingsActivity extends AppCompatActivity {
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(Color.rgb(242, 246, 252));
        root.setPadding(dp(16), dp(12), dp(16), dp(12));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView back = text("›", 34, true, Color.rgb(23, 105, 224));
        back.setGravity(Gravity.CENTER);
        back.setBackgroundResource(R.drawable.bg_icon_circle);
        toolbar.addView(back, new LinearLayout.LayoutParams(dp(46), dp(46)));
        back.setOnClickListener(v -> finish());
        TextView title = text("الإعدادات والخصوصية", 21, true, Color.rgb(16, 43, 80));
        title.setPadding(dp(12), 0, 0, 0);
        toolbar.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(toolbar);

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(14), 0, dp(16));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        addCard(content, "دارك يعمل محليًا", "قاعدة الأعطال والبحث موجودان داخل التطبيق، ولا يتطلبان اتصالًا بالإنترنت أو ربطًا بذكاء اصطناعي.", "وضع العمل");
        addCard(content, "بياناتك على جهازك", "قائمة أجهزتك وسجل إصلاحاتك والصور التي تختار حفظها تُخزّن محليًا داخل التطبيق. لا توجد هنا خدمة حسابات أو مزامنة سحابية.", "الخصوصية");
        int total = new KnowledgeBase(this).all().size();
        addCard(content, "مكتبة الإصلاحات", "الإصدار 26.0.0\nتضم المكتبة الحالية " + total + " حالة وأعطال منزلية شائعة. تُعرض الإرشادات الأولية فقط، وقد يتطلب العطل فحصًا مختصًا.", "معلومات التطبيق");
        addCard(content, "السلامة أولًا", "لا تفتح الأجهزة المتصلة بالكهرباء، ولا تتعامل مع الغاز أو دوائر التبريد المغلقة. أوقف الاستخدام عند الشرر أو رائحة الاحتراق أو التسريب القريب من الكهرباء.", "تنبيه السلامة");

        MaterialButton clear = new MaterialButton(this);
        clear.setText("حذف سجل إصلاحاتي والصور المرفقة");
        clear.setTextSize(14);
        clear.setCornerRadius(dp(14));
        clear.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(180, 35, 24)));
        LinearLayout.LayoutParams clearParams = new LinearLayout.LayoutParams(-1, dp(52));
        clearParams.setMargins(0, dp(8), 0, dp(8));
        content.addView(clear, clearParams);
        clear.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("تأكيد حذف السجل")
            .setMessage("سيُحذف سجل إصلاحاتي والصور المرفقة به نهائيًا من هذا الجهاز. ستظل قائمة أجهزتي محفوظة. هل تريد المتابعة؟")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حذف السجل", (dialog, which) -> {
                new RepairStore(this).clearRepairs();
                Toast.makeText(this, "تم حذف سجل الإصلاحات والصور المرتبطة به", Toast.LENGTH_LONG).show();
            }).show());

        TextView footer = text("دارك • إصدار 26.0.0", 12, false, Color.rgb(99, 117, 141));
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(12), 0, dp(12));
        content.addView(footer);

        setContentView(root);
        getWindow().setStatusBarColor(Color.rgb(242, 246, 252));
        getWindow().setNavigationBarColor(Color.rgb(242, 246, 252));
    }

    private void addCard(LinearLayout parent, String title, String body, String label) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackgroundResource(R.drawable.bg_card);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(0, 0, 0, dp(10));
        parent.addView(card, params);
        TextView heading = text(title, 16, true, Color.rgb(20, 35, 60));
        card.addView(heading);
        TextView content = text(body, 13, false, Color.rgb(83, 100, 124));
        content.setLineSpacing(dp(3), 1f);
        content.setPadding(0, dp(8), 0, 0);
        card.addView(content);
        TextView tag = text(label, 10, true, Color.rgb(23, 105, 224));
        tag.setPadding(0, dp(8), 0, 0);
        card.addView(tag);
    }

    private TextView text(String value, int size, boolean bold, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTextDirection(View.TEXT_DIRECTION_RTL);
        if (bold) view.setTypeface(null, Typeface.BOLD);
        return view;
    }
}
