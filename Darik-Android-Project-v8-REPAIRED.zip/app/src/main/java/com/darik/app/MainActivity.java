package com.darik.app;
import android.content.*;import android.os.Bundle;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;import com.google.android.material.button.MaterialButton;
public class MainActivity extends AppCompatActivity{
 EditText search; TextView history;
 @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);MaterialButton start=findViewById(R.id.btnStart);TextView unknown=findViewById(R.id.btnUnknown);history=findViewById(R.id.historyText);search=findViewById(R.id.searchInput);update();start.setOnClickListener(v->open(search.getText().toString().trim()));unknown.setOnClickListener(v->open(""));findViewById(R.id.btnHistory).setOnClickListener(v->startActivity(new Intent(this,HistoryActivity.class)));findViewById(R.id.btnDevices).setOnClickListener(v->startActivity(new Intent(this,DevicesActivity.class)));}
 void open(String m){Intent i=new Intent(this,DiagnosisActivity.class);i.putExtra("mode",m==null?"":m);startActivity(i);}void update(){history.setText("إصلاحاتي المحفوظة: "+new RepairStore(this).count());}
}
