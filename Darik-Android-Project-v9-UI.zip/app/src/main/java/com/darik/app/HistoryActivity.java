package com.darik.app;
import android.os.Bundle;import android.graphics.Color;import android.view.*;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;import java.util.*;
public class HistoryActivity extends AppCompatActivity{
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,24,24,24);root.setBackgroundColor(Color.rgb(247,248,250));
 TextView title=t("إصلاحاتي",26,true);root.addView(title,new LinearLayout.LayoutParams(-1,60));List<String> list=new RepairStore(this).summaries();
 if(list.isEmpty())root.addView(t("لا توجد إصلاحات محفوظة بعد. ابدأ تشخيص مشكلة وسيظهر سجلها هنا.",17,false));
 for(String s:list){TextView v=t(s,16,false);v.setBackgroundResource(com.darik.app.R.drawable.bg_card);v.setPadding(18,18,18,18);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,12);root.addView(v,lp);}setContentView(root);}
 TextView t(String s,int z,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(Color.rgb(17,24,39));if(bold)v.setTypeface(null,1);return v;}
}
